package com.ansu.anime

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.ansu.anime.core.diagnostics.LogCategory
import com.ansu.anime.di.AppContainer
import kotlinx.coroutines.launch

class AnsuApp : Application(), ImageLoaderFactory {
    lateinit var container: AppContainer
        private set

    /**
     * One app-wide image loader. Posters and thumbnails from AniList and the sources rarely change, so cached
     * copies are reused without asking the server again (`respectCacheHeaders(false)`), which removes a network
     * round trip per image while scrolling and keeps lists smooth and working on a weak connection.
     */
    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.20).build() }
        .diskCache { DiskCache.Builder().directory(cacheDir.resolve("image_cache")).maxSizeBytes(200L * 1024 * 1024).build() }
        .respectCacheHeaders(false)
        .crossfade(false)
        // Animated pictures in comments (GIF, animated WebP) play instead of showing one still frame.
        .components {
            if (android.os.Build.VERSION.SDK_INT >= 28) add(coil.decode.ImageDecoderDecoder.Factory()) else add(coil.decode.GifDecoder.Factory())
        }
        .build()

    override fun onCreate() {
        super.onCreate()
        com.ansu.anime.ui.components.GlassTuning.load(this)
        container = AppContainer(this)
        // Scheduling touches WorkManager (which initializes on first use) and the disk, so it must not run before
        // the first frame. It starts a few milliseconds later and changes nothing the person can see.
        val notificationsOn = container.notificationPrefs.enabled.value
        container.backgroundScope.launch {
            // Keep the scheduled background update check in step with the stored preference.
            container.updateManager.applyAutoCheck()
            // Same for the daily automatic backup, so a fresh install gets one without a tap.
            container.backupManager.applyAutoBackup()
            // Release / new-episode notifications: one scheduled check, kept in step with the master switch.
            if (notificationsOn) {
                com.ansu.anime.data.notify.ReleaseCheckWorker.schedule(this@AnsuApp)
            } else {
                com.ansu.anime.data.notify.ReleaseCheckWorker.cancel(this@AnsuApp)
            }
        }
        // Must be installed as early as possible so a crash at startup is captured too.
        container.diagnostics.installCrashHandler()
        installLinkageGuard()
        container.diagnostics.log(
            LogCategory.APP,
            "Anisu ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE}) started · " +
                "Android ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT}) · " +
                "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}",
        )
    }

    /**
     * An extension built against different library versions can raise a LinkageError (NoSuchMethodError,
     * NoClassDefFoundError...) on a background thread we do not control, e.g. inside an OkHttp or Rx worker.
     * That would close the app, so such an error off the main thread is logged and swallowed instead; the
     * request that caused it simply never completes and times out in the UI.
     */
    private fun installLinkageGuard() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            var cause: Throwable? = error
            var linkage = false
            while (cause != null) {
                if (cause is LinkageError) { linkage = true; break }
                cause = cause.cause?.takeIf { it !== cause }
            }
            if (linkage && thread.name != "main") {
                android.util.Log.e("AnsuApp", "Extension linkage error on ${thread.name} ignored", error)
            } else {
                previous?.uncaughtException(thread, error)
            }
        }
    }
}
