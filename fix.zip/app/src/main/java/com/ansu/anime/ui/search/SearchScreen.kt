@file:OptIn(ExperimentalLayoutApi::class)

package com.ansu.anime.ui.search

import com.ansu.anime.ui.components.BouncyIconButton
import com.ansu.anime.ui.components.recordGlassBackground
import androidx.compose.foundation.background
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.imePadding
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NorthWest
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.util.lerp
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.ansu.anime.anilist.AniListSearchFilters
import com.ansu.anime.core.model.SAnime
import com.ansu.anime.core.util.ageRatingFor
import com.ansu.anime.di.AppContainer
import com.ansu.anime.ui.components.AgeRatingChip
import com.ansu.anime.ui.components.AppBottomBarReserve
import com.ansu.anime.ui.components.BackdropState
import com.ansu.anime.ui.components.LocalNavBarBackdropBlur
import com.ansu.anime.ui.components.backdropBlurSupported
import com.ansu.anime.ui.components.backdropSource
import com.ansu.anime.ui.components.frostedBackdrop
import com.ansu.anime.ui.components.GlassTuning
import com.ansu.anime.ui.components.PressGroup
import com.ansu.anime.ui.components.pressBounce
import com.ansu.anime.ui.components.pressGroupMember
import com.ansu.anime.ui.components.pressGroupWidth
import com.ansu.anime.ui.components.HeavyGlassCard
import com.ansu.anime.ui.components.PosterOriginHandle
import com.ansu.anime.ui.components.posterTransitionAnchor
import com.ansu.anime.ui.components.posterTransitionOrigin
import com.ansu.anime.ui.components.posterTransitionTrigger
import com.ansu.anime.ui.theme.AnsuColors
import kotlinx.coroutines.delay

private fun SAnime.resultKey(): String = id + origin.hashCode()

/** How many titles the panel suggests under a typed query. */
private const val SUGGESTION_COUNT = 5

/** How many top results the panel shows: nine as a grid (three rows of three), five as a list. */
private const val TOP_GRID_COUNT = 9
private const val TOP_LIST_COUNT = 5

/** How many earlier searches the panel shows under a typed query. */
private const val MATCHING_HISTORY_COUNT = 3

@Composable
fun SearchScreen(
    container: AppContainer,
    navController: NavHostController,
    onAnimeSelected: (SAnime) -> Unit,
    backdrop: BackdropState,
) {
    // Held by the app rather than the screen, so opening a result and backing out finds everything as it was.
    val session = container.searchSession
    var query by session::query
    var filters by session::filters
    val isGrid by container.appearancePrefs.searchGrid.collectAsStateWithLifecycle()
    var showFilters by remember { mutableStateOf(false) }

    var results by session::results
    // The query and filters that produced [results]; "load more" must page through those, not
    // through whatever has been typed since.
    var activeQuery by session::activeQuery
    var activeFilters by session::activeFilters
    var page by session::page
    var hasNext by session::hasNext
    var isLoading by remember { mutableStateOf(false) }
    var isLoadingMore by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    var moreFailed by remember { mutableStateOf(false) }
    var retryTick by remember { mutableIntStateOf(0) }
    val titleLanguage by container.appearancePrefs.titleLanguage.collectAsStateWithLifecycle()

    val focusManager = LocalFocusManager.current
    val gridState = session.gridState
    val listState = session.listState
    // With no text and no filters the screen shows trending anime instead of an empty prompt.
    // The sources a search can be limited to: every installed, switched-on source. A chosen source that has been
    // switched off or removed since falls back to "All".
    val installedExtensions by container.extensionManager.extensions.collectAsStateWithLifecycle()
    val disabledSources by container.extensionManager.disabledSourceIds.collectAsStateWithLifecycle()
    val searchableSources = remember(installedExtensions, disabledSources) {
        container.extensionManager.allSources().filter { it.id != com.ansu.anime.extension.BUILT_IN_SOURCE_ID }
    }
    val savedSource by container.appearancePrefs.searchSource.collectAsStateWithLifecycle()
    val sourceId = savedSource?.takeIf { id -> searchableSources.any { it.id == id } }
    val isTrending = query.trim().length < 2 && !filters.isActive && sourceId == null

    // Restarts on every keystroke or filter change, which cancels the previous search: no stale
    // results. Text shorter than two characters counts as no text; with no text and no filters
    // the query resolves to AniList's trending list (30 titles per page).
    LaunchedEffect(query, filters, retryTick, titleLanguage, sourceId) {
        val text = query.trim().takeIf { it.length >= 2 }.orEmpty()
        val key = listOf(text, filters, titleLanguage, sourceId)
        // Coming back to the same search (after a details page, say): keep the results and the scroll position.
        if (retryTick == 0 && session.loadedKey == key) return@LaunchedEffect
        if (text.isNotEmpty()) delay(400) // debounce
        isLoading = true
        failed = false
        moreFailed = false
        val result = if (sourceId != null) {
            container.catalogRepository.searchInSource(sourceId, text, 1)
        } else {
            container.catalogRepository.search(text, filters, 1)
        }
        results = result?.items.orEmpty().distinctBy { it.resultKey() }
        session.remember(results)
        hasNext = result?.hasNextPage == true
        failed = result == null
        session.loadedKey = if (result == null) null else key
        activeQuery = text
        activeFilters = filters
        session.activeSourceId = sourceId
        page = 1
        isLoading = false
        gridState.scrollToItem(0)
        listState.scrollToItem(0)
    }

    // Tablet mode lays list results out in a grid too, so the grid's scroll state is the one to watch there.
    val gridInUse = isGrid || com.ansu.anime.ui.components.LocalTabletMode.current
    val nearEnd by remember(gridInUse) {
        derivedStateOf {
            if (gridInUse) {
                val info = gridState.layoutInfo
                info.totalItemsCount > 0 && (info.visibleItemsInfo.lastOrNull()?.index ?: -1) >= info.totalItemsCount - 4
            } else {
                val info = listState.layoutInfo
                info.totalItemsCount > 0 && (info.visibleItemsInfo.lastOrNull()?.index ?: -1) >= info.totalItemsCount - 4
            }
        }
    }

    // Loads the next page when the user scrolls close to the end. A failed page shows a retry
    // button instead of looping.
    LaunchedEffect(nearEnd, results.size, hasNext, isLoading, moreFailed) {
        if (!nearEnd || !hasNext || isLoading || moreFailed) return@LaunchedEffect
        isLoadingMore = true
        try {
            val pagedSource = session.activeSourceId
            val next = if (pagedSource != null) {
                container.catalogRepository.searchInSource(pagedSource, activeQuery, page + 1)
            } else {
                container.catalogRepository.search(activeQuery, activeFilters, page + 1)
            }
            if (next == null) {
                moreFailed = true
            } else {
                results = (results + next.items).distinctBy { it.resultKey() }
                session.remember(next.items)
                hasNext = next.hasNextPage
                page += 1
            }
        } finally {
            isLoadingMore = false
        }
    }

    // ---- Typo-tolerant suggestions, and the top results the panel shows in the chosen layout ----
    val typedNow = query.trim()
    val suggestions = remember(typedNow, session.poolVersion) {
        if (typedNow.length < 2) {
            emptyList()
        } else {
            rankAnime(typedNow, session.pool())
                .filterNot { TitleMatcher.normalize(it.title) == TitleMatcher.normalize(typedNow) }
                .distinctBy { it.title.lowercase() }
                .take(SUGGESTION_COUNT)
        }
    }
    val panelTopResults = remember(typedNow, results, isLoading, isGrid) {
        if (typedNow.length < 2 || isLoading) {
            emptyList()
        } else {
            // Close matches first; the results AniList returned that the matcher did not rank still fill the rest.
            val ranked = rankAnime(typedNow, results)
            (ranked + results.filterNot { it in ranked })
                .take(if (isGrid) TOP_GRID_COUNT else TOP_LIST_COUNT)
        }
    }

    // ---- Search history and the expanding search panel ----
    val history by container.searchHistory.items.collectAsStateWithLifecycle()
    // True while the search bar is open: the dark panel has grown out of it to the screen's edges and shows the history.
    var searching by remember { mutableStateOf(false) }
    val expand = remember { Animatable(0f) }
    LaunchedEffect(searching) {
        if (searching) {
            expand.animateTo(1f, tween(420, easing = CubicBezierEasing(0.05f, 0.7f, 0.1f, 1f)))
        } else {
            expand.animateTo(0f, tween(320, easing = FastOutSlowInEasing))
        }
    }
    val panelVisible by remember { derivedStateOf { expand.value > 0.001f } }
    // Where the bar sits when closed, and where the area it grows into sits, both in window coordinates.
    var barBounds by remember { mutableStateOf(Rect.Zero) }
    var areaBounds by remember { mutableStateOf(Rect.Zero) }

    fun closeSearch() {
        focusManager.clearFocus()
        searching = false
    }

    // Runs a search for [text] (default: what is typed): remembers it and folds the panel back into the bar.
    fun submit(text: String = query) {
        if (text != query) query = text
        container.searchHistory.add(text)
        closeSearch()
    }
    BackHandler(enabled = searching) { closeSearch() }

    val openResult: (SAnime) -> Unit = { anime ->
        container.searchHistory.add(query)
        onAnimeSelected(anime)
    }

    Scaffold(containerColor = Color.Transparent, bottomBar = { AppBottomBarReserve() }) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = padding.calculateTopPadding())
                .onGloballyPositioned { areaBounds = it.boundsInRoot() },
        ) {
          // Filter chips and results sit under the bar row, which is drawn last so the panel can slide beneath it.
          // Only the results (not the bar itself) are the blur source: the bar samples this layer, so including
          // the bar in it would make the pill blur its own text.
          Column(modifier = Modifier.fillMaxSize().backdropSource(backdrop)) {
            // The filter sheet's options are AniList's, so they are not offered while a single source is searched.
            val chips = if (sourceId == null) activeFilterChips(filters) else emptyList()
            // With no chip row, the results list starts at the top of the screen and its own top content padding
            // puts the first card under the bar; as it scrolls, cards pass behind the bar, which is what the
            // frosted backdrop blurs. With a chip row, the row takes that space instead.
            val chipsRow = sourceId != null || chips.isNotEmpty()
            if (chipsRow) Spacer(Modifier.height(SearchBarRowHeight))
            if (sourceId != null) {
                // The chosen source stays visible under the bar; its cross switches the search back to everything.
                LazyRow(
                    modifier = Modifier.padding(bottom = 6.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    item {
                        val name = searchableSources.firstOrNull { it.id == sourceId }?.name.orEmpty()
                        RemovableChip(label = "Source: $name", onRemove = { container.appearancePrefs.setSearchSource(null) })
                    }
                }
            }
            if (chips.isNotEmpty()) {
                LazyRow(
                    modifier = Modifier.padding(bottom = 6.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    items(chips) { chip ->
                        RemovableChip(label = chip.label, onRemove = { filters = chip.remove(filters) })
                    }
                    item {
                        TextButton(onClick = { filters = AniListSearchFilters() }) {
                            Text("Clear all", color = AnsuColors.TextSecondary)
                        }
                    }
                }
            }

            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                val contentPadding = PaddingValues(
                    start = 12.dp,
                    top = if (chipsRow) 6.dp else SearchBarRowHeight + 6.dp,
                    end = 12.dp,
                    bottom = 12.dp + padding.calculateBottomPadding(),
                )
                when {
                    isLoading -> CircularProgressIndicator(
                        color = AnsuColors.Accent,
                        strokeWidth = 2.dp,
                        modifier = Modifier.align(Alignment.Center).size(28.dp),
                    )
                    failed -> Box(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        com.ansu.anime.ui.components.ErrorGlassCard(
                            title = "Couldn't load results",
                            message = "Check your connection and try again.",
                            onRetry = { retryTick += 1 },
                        )
                    }
                    results.isEmpty() -> MessageState(
                        title = "No results found",
                        body = "Try a different title or loosen some filters.",
                    )
                    // Tablet mode: the grid fits as many posters as the width allows, and list mode becomes two columns.
                    isGrid || com.ansu.anime.ui.components.LocalTabletMode.current -> LazyVerticalGrid(
                        state = gridState,
                        columns = when {
                            !com.ansu.anime.ui.components.LocalTabletMode.current -> GridCells.Fixed(3)
                            isGrid -> GridCells.Adaptive(minSize = 150.dp)
                            else -> GridCells.Fixed(2)
                        },
                        contentPadding = contentPadding,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        item(span = { GridItemSpan(maxLineSpan) }, key = "header") {
                            ResultsHeader(isTrending)
                        }
                        items(results, key = { it.resultKey() }) { anime ->
                            if (isGrid) {
                                SearchGridCard(anime = anime, onClick = { openResult(anime) })
                            } else {
                                SearchListItem(anime = anime, onClick = { openResult(anime) })
                            }
                        }
                        if (hasNext || moreFailed) {
                            item(span = { GridItemSpan(maxLineSpan) }) {
                                LoadMoreFooter(failed = moreFailed, onRetry = { moreFailed = false })
                            }
                        }
                    }
                    else -> LazyColumn(
                        state = listState,
                        contentPadding = contentPadding,
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        item(key = "header") { ResultsHeader(isTrending) }
                        items(results, key = { it.resultKey() }) { anime ->
                            SearchListItem(anime = anime, onClick = { openResult(anime) })
                        }
                        if (hasNext || moreFailed) {
                            item {
                                LoadMoreFooter(failed = moreFailed, onRetry = { moreFailed = false })
                            }
                        }
                    }
                }
            }
          }

          if (panelVisible) {
              SearchPanel(
                  panelBackgroundStyle = container.appearancePrefs.backgroundStyle.collectAsStateWithLifecycle().value,
                  expand = { expand.value },
                  barBounds = { barBounds },
                  areaBounds = { areaBounds },
                  history = history,
                  suggestions = suggestions,
                  topResults = panelTopResults,
                  topSearching = typedNow.length >= 2 && isLoading,
                  isGrid = isGrid,
                  filter = query.trim(),
                  bottomPadding = padding.calculateBottomPadding(),
                  onPick = { submit(it) },
                  onFill = { query = it },
                  onRemove = container.searchHistory::remove,
                  onClearAll = container.searchHistory::clear,
                  onOpen = { anime -> closeSearch(); openResult(anime) },
              )
          }

          val pressGroup = com.ansu.anime.ui.components.rememberPressGroup()
          Row(
              modifier = Modifier
                  .fillMaxWidth()
                  .height(SearchBarRowHeight)
                  .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
          ) {
              SearchField(
                  value = query,
                  onValueChange = { query = it },
                  onClear = { query = "" },
                  onSearch = { submit() },
                  searching = searching,
                  onBack = { closeSearch() },
                  onFocused = { searching = true },
                  backdrop = backdrop,
                  modifier = Modifier
                      .weight(1f)
                      .height(52.dp)
                      .pressGroupMember(pressGroup, 0)
                      .onGloballyPositioned { if (!searching && expand.value == 0f) barBounds = it.boundsInRoot() },
              )
              // While the bar is open it takes the whole row; the two buttons fold away and come back with it.
              AnimatedVisibility(
                  visible = !searching,
                  enter = fadeIn() + expandHorizontally(),
                  exit = fadeOut() + shrinkHorizontally(),
              ) {
                  // The icon shows the view you will switch TO: a grid while in list view, and vice versa.
                  GlassIconButton(
                      icon = if (isGrid) Icons.AutoMirrored.Filled.ViewList else Icons.Filled.GridView,
                      contentDescription = if (isGrid) "Switch to list view" else "Switch to grid view",
                      onClick = { container.appearancePrefs.setSearchGrid(!isGrid) },
                      backdrop = backdrop,
                      group = pressGroup,
                      index = 1,
                      modifier = Modifier.padding(start = 10.dp),
                  )
              }
              AnimatedVisibility(
                  visible = !searching,
                  enter = fadeIn() + expandHorizontally(),
                  exit = fadeOut() + shrinkHorizontally(),
              ) {
                  GlassIconButton(
                      icon = Icons.Filled.Tune,
                      contentDescription = "Filters",
                      badgeCount = filters.activeCount,
                      backdrop = backdrop,
                      group = pressGroup,
                      index = 2,
                      onClick = {
                          focusManager.clearFocus()
                          showFilters = true
                      },
                      modifier = Modifier.padding(start = 10.dp),
                  )
              }
          }
        }
    }

    if (showFilters) {
        SearchFilterSheet(
            filters = filters,
            sources = searchableSources.let { all ->
                val sameName = all.groupingBy { it.name }.eachCount()
                all.map { source ->
                    source.id to if ((sameName[source.name] ?: 0) > 1 && source.lang.isNotBlank()) "${source.name} (${source.lang})" else source.name
                }
            },
            sourceId = sourceId,
            onApply = { newFilters, newSource ->
                filters = newFilters
                container.appearancePrefs.setSearchSource(newSource)
                showFilters = false
            },
            onDismiss = { showFilters = false },
        )
    }
}

/** Small heading above the results: "Trending now" on the landing state, otherwise "Results". */
@Composable
private fun ResultsHeader(isTrending: Boolean) {
    Text(
        text = if (isTrending) "Trending now" else "Results",
        style = MaterialTheme.typography.titleMedium,
        color = AnsuColors.TextPrimary,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 4.dp, bottom = 2.dp),
    )
}

/** The pill-shaped glass search field: search icon, hint, and a clear button while there is text. */
@Composable
private fun SearchField(
    value: String,
    onValueChange: (String) -> Unit,
    onClear: () -> Unit,
    onSearch: () -> Unit,
    searching: Boolean,
    onBack: () -> Unit,
    onFocused: () -> Unit,
    backdrop: BackdropState? = null,
    modifier: Modifier = Modifier,
) {
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        textStyle = MaterialTheme.typography.bodyLarge.copy(color = AnsuColors.TextPrimary),
        cursorBrush = SolidColor(AnsuColors.Accent),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        modifier = modifier.onFocusChanged { if (it.isFocused) onFocused() },
        decorationBox = { innerTextField ->
            // The same card as the list and filter buttons beside it (page-dark fill, light rim), so the pill is
            // visible on a pure black page too: the old translucent black fill vanished on AMOLED black.
            val blurActive = LocalNavBarBackdropBlur.current && backdropBlurSupported && backdrop != null
            HeavyGlassCard(
                modifier = Modifier.fillMaxSize().frostedBackdrop(backdrop, LocalNavBarBackdropBlur.current, CircleShape),
                shape = CircleShape,
                tintAlpha = if (blurActive) 0.45f else GlassTuning.cardTintAlpha,
                sampleBackground = !blurActive,
            ) {
                Row(
                    modifier = Modifier.fillMaxSize().padding(start = 8.dp, end = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    // The magnifier turns into a back arrow while the bar is open.
                    Crossfade(targetState = searching, label = "searchLeadingIcon") { open ->
                        if (open) {
                            BouncyIconButton(onClick = onBack, modifier = Modifier.size(36.dp)) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Close search",
                                    tint = AnsuColors.TextPrimary,
                                    modifier = Modifier.size(20.dp),
                                )
                            }
                        } else {
                            Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Filled.Search,
                                    contentDescription = null,
                                    tint = AnsuColors.TextSecondary,
                                    modifier = Modifier.size(20.dp),
                                )
                            }
                        }
                    }
                    Box(
                        modifier = Modifier.weight(1f).padding(start = 2.dp, end = 10.dp),
                        contentAlignment = Alignment.CenterStart,
                    ) {
                        if (value.isEmpty()) {
                            Text(
                                text = "Search anime...",
                                style = MaterialTheme.typography.bodyLarge,
                                color = AnsuColors.TextTertiary,
                                maxLines = 1,
                            )
                        }
                        innerTextField()
                    }
                    if (value.isNotEmpty()) {
                        BouncyIconButton(onClick = onClear, modifier = Modifier.size(36.dp)) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Clear search",
                                tint = AnsuColors.TextSecondary,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }
                }
            }
        },
    )
}

/** The height of the bar row: 12dp above the 52dp bar and 10dp below it. */
private val SearchBarRowHeight = 74.dp

/** Clips whatever it is applied to to [rect] with rounded corners, so a full-size panel can be revealed from a small one. */
private class RevealShape(private val rect: Rect, private val radius: Float) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline =
        Outline.Rounded(RoundRect(rect, CornerRadius(radius)))
}

/**
 * The dark panel that grows out of the search bar to the edges of the screen. With nothing typed it lists the search
 * history. While something is typed it shows, top to bottom: the earlier searches that match it, up to five titles
 * close to it, and the top results in the chosen layout (nine as a grid, five as a list).
 * It is laid out at full size the whole time and only the clip grows (from the bar's rectangle and rounded corners
 * to the whole area with square corners), so the list never reflows mid-animation; it fades in as the panel opens.
 */
@Composable
private fun SearchPanel(
    expand: () -> Float,
    barBounds: () -> Rect,
    areaBounds: () -> Rect,
    history: List<String>,
    filter: String,
    suggestions: List<SAnime>,
    topResults: List<SAnime>,
    topSearching: Boolean,
    isGrid: Boolean,
    bottomPadding: Dp,
    onPick: (String) -> Unit,
    onFill: (String) -> Unit,
    onRemove: (String) -> Unit,
    onClearAll: () -> Unit,
    onOpen: (SAnime) -> Unit,
    panelBackgroundStyle: com.ansu.anime.data.prefs.BackgroundStyle,
) {
    val typing = filter.isNotEmpty()
    // While something is typed, only the earlier searches that match it are shown, the newest few.
    val shown = if (typing) {
        history.filter { it.contains(filter, ignoreCase = true) }.take(MATCHING_HISTORY_COUNT)
    } else {
        history
    }
    val glassBackground = com.ansu.anime.ui.components.rememberGlassBackground()
    androidx.compose.runtime.CompositionLocalProvider(
        com.ansu.anime.ui.components.LocalGlassBackground provides glassBackground,
    ) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer {
                val p = expand()
                val area = areaBounds()
                val from = barBounds().translate(-area.topLeft)
                val rect = Rect(
                    left = lerp(from.left, 0f, p),
                    top = lerp(from.top, 0f, p),
                    right = lerp(from.right, size.width, p),
                    bottom = lerp(from.bottom, size.height, p),
                )
                shape = RevealShape(rect, lerp(26.dp.toPx(), 0f, p))
                clip = true
            }
            .drawBehind {
                // Fully dark almost at once, so the see-through bar never shows a dark patch under it at the start.
                drawRect(AnsuColors.Background.copy(alpha = (expand() * 8f).coerceAtMost(1f)))
            }
            // Taps on the empty part of the panel must not reach the results underneath.
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        // The panel covers the results with solid colour, so the animated background is drawn inside it too.
        com.ansu.anime.ui.components.BackgroundAnimation(
            style = panelBackgroundStyle,
            modifier = Modifier.recordGlassBackground(glassBackground, AnsuColors.Background),
        )
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .imePadding()
                .graphicsLayer {
                    val p = expand()
                    alpha = ((p - 0.25f) / 0.6f).coerceIn(0f, 1f)
                    translationY = (1f - p) * 24.dp.toPx()
                },
            contentPadding = PaddingValues(top = SearchBarRowHeight + 4.dp, bottom = 12.dp + bottomPadding),
        ) {
            if (!typing) {
                if (history.isEmpty()) {
                    item(key = "empty") {
                        EmptyPanelText("Your searches will show up here.")
                    }
                } else {
                    item(key = "header") {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "Search history",
                                style = MaterialTheme.typography.titleSmall,
                                color = AnsuColors.TextPrimary,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f),
                            )
                            TextButton(onClick = onClearAll) { Text("Clear all", color = AnsuColors.TextSecondary) }
                        }
                    }
                    items(history, key = { it }) { entry ->
                        SearchHistoryRow(
                            text = entry,
                            onPick = { onPick(entry) },
                            onFill = { onFill(entry) },
                            onRemove = { onRemove(entry) },
                        )
                    }
                }
            } else {
                if (shown.isNotEmpty()) {
                    item(key = "history-header") { PanelSectionHeader("From your searches") }
                    items(shown, key = { "history-$it" }) { entry ->
                        SearchHistoryRow(
                            text = entry,
                            onPick = { onPick(entry) },
                            onFill = { onFill(entry) },
                            onRemove = { onRemove(entry) },
                        )
                    }
                }
                if (suggestions.isNotEmpty()) {
                    item(key = "suggest-header") { PanelSectionHeader("Suggestions") }
                    items(suggestions, key = { "suggest-${it.title}" }) { anime ->
                        SuggestionRow(
                            title = anime.title,
                            onOpen = { onOpen(anime) },
                            onFill = { onFill(anime.title) },
                        )
                    }
                }
                if (topSearching || topResults.isNotEmpty()) {
                    item(key = "top-header") { PanelSectionHeader("Top results") }
                    when {
                        topSearching -> item(key = "top-loading") { PanelSpinner() }
                        isGrid -> item(key = "top-grid") { PanelGrid(topResults, onOpen) }
                        else -> items(topResults, key = { "top-${it.resultKey()}" }) { anime ->
                            Box(modifier = Modifier.padding(horizontal = 12.dp)) {
                                SearchListItem(anime = anime, onClick = { onOpen(anime) }, animateOpen = true)
                            }
                        }
                    }
                }
                if (shown.isEmpty() && suggestions.isEmpty() && topResults.isEmpty() && !topSearching) {
                    item(key = "nomatch") { EmptyPanelText("No matching searches.") }
                }
            }
        }
    }
    }
}

/** The top results as three-by-three rows of posters, the same look as the grid below the bar. */
@Composable
private fun PanelGrid(animes: List<SAnime>, onOpen: (SAnime) -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        animes.chunked(3).forEach { rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                rowItems.forEach { anime ->
                    Box(modifier = Modifier.weight(1f)) {
                        SearchGridCard(anime = anime, onClick = { onOpen(anime) }, animateOpen = true)
                    }
                }
                repeat(3 - rowItems.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

/** A small heading inside the panel, such as "Suggestions". */
@Composable
private fun PanelSectionHeader(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleSmall,
        color = AnsuColors.TextPrimary,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 4.dp),
    )
}

/** One suggested title: tap to open it, the arrow to copy the title into the search bar. */
@Composable
private fun SuggestionRow(title: String, onOpen: () -> Unit, onFill: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen)
            .padding(start = 20.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = Icons.Filled.Search,
            contentDescription = null,
            tint = AnsuColors.TextTertiary,
            modifier = Modifier.size(20.dp),
        )
        Text(
            text = title,
            color = AnsuColors.TextPrimary,
            style = MaterialTheme.typography.bodyLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f).padding(horizontal = 16.dp, vertical = 14.dp),
        )
        BouncyIconButton(onClick = onFill, modifier = Modifier.size(40.dp)) {
            Icon(
                imageVector = Icons.Filled.NorthWest,
                contentDescription = "Use in search bar",
                tint = AnsuColors.TextSecondary,
                modifier = Modifier.size(18.dp),
            )
        }
    }
}

@Composable
private fun PanelSpinner() {
    Box(modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = AnsuColors.Accent, strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
    }
}

@Composable
private fun EmptyPanelText(text: String) {
    Text(
        text = text,
        color = AnsuColors.TextTertiary,
        style = MaterialTheme.typography.bodyMedium,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 28.dp),
        textAlign = TextAlign.Center,
    )
}

/** One remembered search: tap to run it, the arrow to copy it into the bar for editing, the cross to forget it. */
@Composable
private fun SearchHistoryRow(text: String, onPick: () -> Unit, onFill: () -> Unit, onRemove: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onPick)
            .padding(start = 20.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = Icons.Filled.History,
            contentDescription = null,
            tint = AnsuColors.TextTertiary,
            modifier = Modifier.size(20.dp),
        )
        Text(
            text = text,
            color = AnsuColors.TextPrimary,
            style = MaterialTheme.typography.bodyLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f).padding(horizontal = 16.dp, vertical = 14.dp),
        )
        BouncyIconButton(onClick = onRemove, modifier = Modifier.size(40.dp)) {
            Icon(
                imageVector = Icons.Filled.Close,
                contentDescription = "Remove from history",
                tint = AnsuColors.TextSecondary,
                modifier = Modifier.size(18.dp),
            )
        }
        BouncyIconButton(onClick = onFill, modifier = Modifier.size(40.dp)) {
            Icon(
                imageVector = Icons.Filled.NorthWest,
                contentDescription = "Use in search bar",
                tint = AnsuColors.TextSecondary,
                modifier = Modifier.size(18.dp),
            )
        }
    }
}

/** A rounded-square glass button; [badgeCount] above zero adds a small white count badge. */
@Composable
private fun GlassIconButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    badgeCount: Int = 0,
    backdrop: BackdropState? = null,
    group: PressGroup? = null,
    index: Int = 0,
) {
    // In the search row the buttons swell and squeeze each other; on their own they just bounce.
    val sizing = if (group != null) Modifier.height(52.dp).pressGroupWidth(group, index, 52.dp) else Modifier.size(52.dp).pressBounce()
    Box(modifier = modifier.then(sizing)) {
        val blurActive = LocalNavBarBackdropBlur.current && backdropBlurSupported && backdrop != null
        HeavyGlassCard(
            modifier = Modifier.fillMaxSize().frostedBackdrop(backdrop, LocalNavBarBackdropBlur.current, RoundedCornerShape(18.dp)),
            shape = RoundedCornerShape(18.dp),
            tintAlpha = if (blurActive) 0.4f else 0.55f,
            sampleBackground = !blurActive,
        ) {
            Box(
                modifier = Modifier.fillMaxSize().clickable(onClick = onClick),
                contentAlignment = Alignment.Center,
            ) {
                Icon(imageVector = icon, contentDescription = contentDescription, tint = AnsuColors.TextPrimary)
            }
        }
        if (badgeCount > 0) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 4.dp, y = (-4).dp)
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(AnsuColors.Accent),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = badgeCount.toString(),
                    color = AnsuColors.OnAccent,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}

@Composable
private fun RemovableChip(label: String, onRemove: () -> Unit) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(AnsuColors.AccentSoft)
            .clickable(onClick = onRemove)
            .padding(start = 12.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = AnsuColors.TextPrimary, fontSize = 12.sp, maxLines = 1)
        Icon(
            imageVector = Icons.Filled.Close,
            contentDescription = "Remove $label",
            tint = AnsuColors.TextSecondary,
            modifier = Modifier.padding(start = 6.dp).size(14.dp),
        )
    }
}

/** Grid mode: poster with the age-rating chip top-left and the title over a scrim at the bottom. */
@Composable
private fun SearchGridCard(anime: SAnime, onClick: () -> Unit, animateOpen: Boolean = true) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(2f / 3f)
            .let { if (animateOpen) it.posterTransitionOrigin(anime.posterUrl, 14.dp) else it }
            .clip(RoundedCornerShape(14.dp))
            .background(AnsuColors.BackgroundElevated)
            .clickable(onClick = onClick),
    ) {
        AsyncImage(
            model = anime.posterUrl,
            contentDescription = anime.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(76.dp)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f)))),
        )
        AgeRatingChip(
            rating = anime.ageRating ?: ageRatingFor(anime.genres, isAdult = false),
            modifier = Modifier.align(Alignment.TopStart).padding(6.dp),
        )
        Text(
            text = anime.title,
            color = AnsuColors.TextPrimary,
            fontSize = 12.sp,
            lineHeight = 15.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.BottomStart).padding(horizontal = 8.dp, vertical = 8.dp),
        )
    }
}

/** List mode: poster on the left; name, episodes and year, genre tags and format on the right. */
@Composable
private fun SearchListItem(anime: SAnime, onClick: () -> Unit, animateOpen: Boolean = true) {
    // A tap anywhere on the row (title, tags, empty space) opens the page out of its poster, not only a tap on the poster.
    val originHandle = remember { PosterOriginHandle() }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(AnsuColors.BackgroundElevated)
            .let { if (animateOpen) it.posterTransitionTrigger(originHandle, anime.posterUrl, 12.dp) else it }
            .clickable(onClick = onClick)
            .padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            modifier = Modifier
                .width(96.dp)
                .aspectRatio(2f / 3f)
                .let { if (animateOpen) it.posterTransitionAnchor(originHandle) else it }
                .clip(RoundedCornerShape(12.dp))
                .background(AnsuColors.Background),
        ) {
            AsyncImage(
                model = anime.posterUrl,
                contentDescription = anime.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
            AgeRatingChip(
                rating = anime.ageRating ?: ageRatingFor(anime.genres, isAdult = false),
                modifier = Modifier.align(Alignment.TopStart).padding(6.dp),
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = anime.title,
                style = MaterialTheme.typography.titleSmall,
                color = AnsuColors.TextPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            val episodesText = anime.episodes?.let { if (it == 1) "1 episode" else "$it episodes" }
            val meta = listOfNotNull(episodesText, anime.releaseYear?.toString()).joinToString(" \u2022 ")
            if (meta.isNotEmpty()) {
                Text(
                    text = meta,
                    fontSize = 12.sp,
                    color = AnsuColors.TextSecondary,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
            if (anime.genres.isNotEmpty()) {
                FlowRow(
                    modifier = Modifier.padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    anime.genres.take(3).forEach { genre -> TagPill(genre) }
                }
            }
            anime.format?.let { format ->
                Text(
                    text = format,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = AnsuColors.TextPrimary,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        }
    }
}

@Composable
private fun TagPill(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(AnsuColors.SurfaceGlassBase.copy(alpha = 0.7f))
            .padding(horizontal = 10.dp, vertical = 4.dp),
    ) {
        Text(text, style = MaterialTheme.typography.labelSmall, color = AnsuColors.TextSecondary, maxLines = 1)
    }
}

@Composable
private fun LoadMoreFooter(failed: Boolean, onRetry: () -> Unit) {
    Box(modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp), contentAlignment = Alignment.Center) {
        if (failed) {
            TextButton(onClick = onRetry) {
                Text("Couldn't load more. Tap to retry", color = AnsuColors.TextSecondary)
            }
        } else {
            CircularProgressIndicator(color = AnsuColors.Accent, strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
        }
    }
}

/** Centered empty / error / hint state with an optional action button. */
@Composable
private fun MessageState(
    title: String,
    body: String,
    modifier: Modifier = Modifier,
    showIcon: Boolean = false,
    actionLabel: String? = null,
    onAction: () -> Unit = {},
) {
    Column(
        modifier = modifier.fillMaxSize().padding(horizontal = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        if (showIcon) {
            Icon(
                imageVector = Icons.Filled.Search,
                contentDescription = null,
                tint = AnsuColors.TextTertiary,
                modifier = Modifier.size(44.dp).padding(bottom = 4.dp),
            )
        }
        Text(title, style = MaterialTheme.typography.titleSmall, color = AnsuColors.TextPrimary, textAlign = TextAlign.Center)
        Text(
            body,
            style = MaterialTheme.typography.bodyMedium,
            color = AnsuColors.TextTertiary,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 6.dp),
        )
        if (actionLabel != null) {
            Button(
                onClick = onAction,
                modifier = Modifier.padding(top = 16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AnsuColors.Accent, contentColor = AnsuColors.OnAccent),
            ) {
                Text(actionLabel, fontWeight = FontWeight.Bold)
            }
        }
    }
}
