package com.ansu.anime.ui.components

import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** True when the platform can blur a layer (RenderEffect, Android 12+); older versions keep the plain frosted glass. */
val backdropBlurSupported: Boolean get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

/**
 * A screen's content, recorded into a layer so a floating bar can draw a blurred copy of whatever is
 * scrolling behind it. The bar must be a sibling of the content (the Scaffold's bottomBar slot), never
 * inside it, otherwise it would try to draw itself into itself.
 */
class BackdropState internal constructor() {
    /**
     * The content source currently behind the bar. Observable on purpose: the bar's draw reads it, so the bar redraws
     * the moment a screen has been laid out (as a plain field the bar had already drawn with nothing to blur and
     * stayed that way until a scroll happened to redraw it).
     */
    internal var active: BackdropSource? by mutableStateOf(null)
}

/**
 * One screen's own recording layer and position. Each tab screen records into its OWN layer: they used to share a
 * single layer, so while two tabs were composed at once (a tab change cross-fades) the screen that was not
 * re-recording drew the other screen's content from the shared layer. That is the "My Space drawn over Home with a
 * stuck spinner until I touch it" glitch, which showed up exactly when a tab was switched while it was still loading.
 */
internal class BackdropSource(val layer: GraphicsLayer) {
    var coordinates: LayoutCoordinates? by mutableStateOf(null)
}

@Composable
fun rememberBackdropState(): BackdropState = remember { BackdropState() }

/**
 * Marks the full-size content behind a floating bar as the source of its blurred backdrop. The newest source to
 * appear is the one the bar blurs; a source that leaves only clears the bar if it is still the active one, so the
 * screen fading out never takes the blur away from the screen fading in.
 */
@Composable
fun Modifier.backdropSource(state: BackdropState): Modifier {
    val layer = rememberGraphicsLayer()
    val source = remember(layer) { BackdropSource(layer) }
    DisposableEffect(state, source) {
        state.active = source
        onDispose { if (state.active === source) state.active = null }
    }
    return this
        .onGloballyPositioned { source.coordinates = it }
        .drawWithContent {
            // Record the content only: the screen itself stays see-through so the animated background shows.
            // The page colour is added underneath in frostedBackdrop, for the blurred copy only.
            source.layer.record { this@drawWithContent.drawContent() }
            drawLayer(source.layer)
        }
}

/**
 * The bar's own coordinates. Observable for the same reason as [BackdropState.coordinates]; the instance only
 * changes when the bar is re-attached, so reading it in the draw block does not redraw on every frame.
 */
private class BackdropBarHolder {
    var coordinates: LayoutCoordinates? by mutableStateOf(null)
}

/**
 * Draws, inside [shape], the part of [state]'s content that sits behind this element, blurred by [radius].
 * Does nothing when there is no [state], when [enabled] is false or below Android 12, so the element simply
 * keeps its normal frosted look there.
 */
@Composable
fun Modifier.frostedBackdrop(state: BackdropState?, enabled: Boolean, shape: Shape, radius: Dp = 22.dp): Modifier {
    if (state == null || !enabled || !backdropBlurSupported) return this
    val blurLayer = rememberGraphicsLayer()
    val holder = remember { BackdropBarHolder() }
    val radiusPx = with(LocalDensity.current) { radius.toPx() }
    // Set once per radius, not on every draw: a fresh effect object each frame made the layer re-validate its blur.
    remember(blurLayer, radiusPx) { blurLayer.renderEffect = BlurEffect(radiusPx, radiusPx, TileMode.Clamp) }
    return this
        .onGloballyPositioned { holder.coordinates = it }
        .clip(shape)
        .drawBehind {
            val active = state.active ?: return@drawBehind
            val source = active.coordinates ?: return@drawBehind
            val me = holder.coordinates ?: return@drawBehind
            if (!source.isAttached || !me.isAttached) return@drawBehind
            val topLeft = source.localPositionOf(me, Offset.Zero)
            blurLayer.record {
                // The screens are see-through (the animation sits behind them), so the blurred copy gets the page
                // colour underneath. Without it the blur only had pixels where a poster or card was, which made
                // the frosted areas look like blotches instead of an even haze.
                drawRect(com.ansu.anime.ui.theme.AnsuColors.Background)
                translate(-topLeft.x, -topLeft.y) { drawLayer(active.layer) }
            }
            drawLayer(blurLayer)
        }
}
