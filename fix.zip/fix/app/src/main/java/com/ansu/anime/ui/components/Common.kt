package com.ansu.anime.ui.components

import androidx.compose.foundation.layout.statusBarsPadding
import com.ansu.anime.data.notify.NotificationEntry
import androidx.compose.foundation.Image
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlin.math.roundToInt
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.geometry.Size
import kotlin.math.abs
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import androidx.compose.foundation.layout.heightIn
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import com.ansu.anime.core.model.SAnime
import com.ansu.anime.core.util.ageRatingFor
import com.ansu.anime.core.util.formatEpisodeNumber
import com.ansu.anime.core.util.progressFraction
import com.ansu.anime.data.db.ContinueWatchingEntity
import com.ansu.anime.ui.theme.AnsuColors

@Composable
fun ShelfHeader(title: String, modifier: Modifier = Modifier) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        color = AnsuColors.TextPrimary,
        modifier = modifier.padding(start = 20.dp, top = 26.dp, bottom = 12.dp),
    )
}

/** A poster-only catalogue row — the generic browse shelf used for extension and AniList lists. */
@Composable
fun PosterRow(items: List<SAnime>, onClick: (SAnime) -> Unit, modifier: Modifier = Modifier) {
    LazyRow(
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(items, key = { it.origin.hashCode().toLong() + it.id.hashCode() }) { anime ->
            AnimeCard(anime = anime, onClick = { onClick(anime) })
        }
    }
}

/**
 * A poster row that never runs dry: when the user scrolls to within a few posters of
 * the end it calls [onLoadMore], and a trailing spinner shows while the next page is
 * fetched. If a page fails the spinner becomes a retry button (no automatic retry loop).
 */
@Composable
fun PagedPosterRow(
    items: List<SAnime>,
    hasMore: Boolean,
    isLoadingMore: Boolean,
    loadFailed: Boolean,
    onLoadMore: () -> Unit,
    onClick: (SAnime) -> Unit,
    modifier: Modifier = Modifier,
) {
    val listState = rememberLazyListState()
    val nearEnd by remember(hasMore) {
        derivedStateOf {
            val info = listState.layoutInfo
            val lastVisible = info.visibleItemsInfo.lastOrNull()?.index ?: -1
            hasMore && lastVisible >= info.totalItemsCount - 3
        }
    }
    // Keyed on the list size and loading flag too, so a page that lands while the row
    // is still near the end immediately triggers the next one.
    LaunchedEffect(nearEnd, items.size, isLoadingMore, loadFailed) {
        if (nearEnd && !isLoadingMore && !loadFailed) onLoadMore()
    }

    LazyRow(
        state = listState,
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(items, key = { it.id }) { anime ->
            AnimeCard(anime = anime, onClick = { onClick(anime) })
        }
        if (hasMore) {
            item(key = "paged-row-footer") {
                Box(
                    modifier = Modifier.width(56.dp).height(195.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    if (loadFailed) {
                        IconButton(onClick = onLoadMore) {
                            Icon(
                                imageVector = Icons.Filled.Refresh,
                                contentDescription = "Retry loading more",
                                tint = AnsuColors.TextPrimary,
                            )
                        }
                    } else {
                        CircularProgressIndicator(
                            color = AnsuColors.Accent,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(24.dp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AnimeCard(anime: SAnime, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier = modifier.width(130.dp).clickable(onClick = onClick)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .posterTransitionOrigin(anime.posterUrl, 12.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(AnsuColors.BackgroundElevated),
        ) {
            AsyncImage(
                model = anime.posterUrl,
                contentDescription = anime.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
            AgeRatingChip(
                rating = anime.ageRating ?: ageRatingFor(anime.genres, isAdult = false),
                modifier = Modifier.align(Alignment.TopStart).padding(6.dp),
            )
        }
        Text(
            text = anime.title,
            style = MaterialTheme.typography.bodyMedium,
            color = AnsuColors.TextPrimary,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp),
        )
    }
}

/**
 * The small frosted-glass age-rating chip pinned to a poster's top-left corner. Real backdrop
 * blur is not available without extra plumbing (see [HeavyGlassCard]), so the glass is a dark
 * tint with a white sheen and a light stroke, which stays legible on both bright and dark art.
 */
@Composable
fun AgeRatingChip(rating: String, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(8.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .background(Color.Black.copy(alpha = 0.55f))
            .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.26f), Color.White.copy(alpha = 0.06f))))
            .border(width = 0.75.dp, color = Color.White.copy(alpha = 0.30f), shape = shape)
            .padding(horizontal = 6.dp, vertical = 2.dp),
    ) {
        Text(
            text = rating,
            color = AnsuColors.TextPrimary,
            fontSize = 10.sp,
            lineHeight = 12.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
        )
    }
}

/**
 * Frosted-glass label pinned along a poster's bottom edge (e.g. "Season 2", "Sequel · Movie"),
 * styled like [AgeRatingChip] so the top-left corner stays free for the age rating.
 */
@Composable
fun PosterGlassLabel(text: String, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(8.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .background(Color.Black.copy(alpha = 0.55f))
            .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.26f), Color.White.copy(alpha = 0.06f))))
            .border(width = 0.75.dp, color = Color.White.copy(alpha = 0.30f), shape = shape)
            .padding(horizontal = 6.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            color = AnsuColors.TextPrimary,
            fontSize = 11.sp,
            lineHeight = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/**
 * The picture part of a continue-watching card: thumbnail, play glyph and burned-in progress bar.
 * [scale] sizes the glyph and the bar, so the enlarged copy shown by the long-press menu
 * (laid out bigger and scaled down to meet the real card) looks the same as the card it came from.
 * The caller supplies the clip shape and size.
 */
@Composable
fun ContinueWatchingThumbnail(
    entry: ContinueWatchingEntity,
    modifier: Modifier = Modifier,
    scale: Float = 1f,
    info: ResumeCardInfo? = null,
) {
    // One fixed decode size for every copy of this thumbnail, so the card and its enlarged twin share
    // a memory-cache entry and the twin appears on its first frame instead of loading in.
    val context = LocalContext.current
    // A finished episode with a next one out shows that episode's own thumbnail, like a "Next Up" tile.
    // The show's wide banner; with none, the "No image" gradient (a portrait poster crops badly in this wide card).
    val banner = entry.bannerUrl
    val episodeThumb = (info as? ResumeCardInfo.NextUp)?.thumbnailUrl?.takeIf { it.isNotBlank() }
    // If the episode thumbnail is missing or fails to load, the show's horizontal banner is used instead.
    var thumbFailed by remember(episodeThumb) { mutableStateOf(false) }
    val url = if (episodeThumb != null && !thumbFailed) episodeThumb else banner
    val request = remember(url) {
        ImageRequest.Builder(context).data(url).size(coil.size.Size(720, 405)).build()
    }
    val overlayCard = info is ResumeCardInfo.NextUp || info is ResumeCardInfo.Countdown
    Box(modifier = modifier.background(AnsuColors.BackgroundElevated)) {
        if (url.isNullOrBlank()) {
            NoImageBanner(textBias = if (overlayCard) 0f else -0.5f, scale = scale)
        } else {
            AsyncImage(
                model = request,
                contentDescription = entry.title,
                contentScale = ContentScale.Crop,
                onError = { if (episodeThumb != null) thumbFailed = true },
                modifier = Modifier.fillMaxSize(),
            )
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f)))),
        )
        if (!overlayCard) {
            Icon(
                imageVector = Icons.Filled.PlayArrow,
                contentDescription = "Resume",
                tint = AnsuColors.TextPrimary,
                modifier = Modifier.align(Alignment.Center).size(36.dp * scale),
            )
        }

        // Glass chip, top right: "Next Up", the air countdown, or the time left in the episode.
        val chipText: String? = when (info) {
            is ResumeCardInfo.NextUp -> "Next Up"
            is ResumeCardInfo.Countdown -> rememberAirText(info.airAtMs)
            is ResumeCardInfo.Remaining -> formatTimeLeft(info.secondsLeft)
            else -> null
        }
        if (chipText != null) {
            Text(
                text = chipText,
                color = AnsuColors.TextPrimary,
                fontSize = 11.sp * scale,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp * scale)
                    .background(AnsuColors.SurfaceGlassBase.copy(alpha = 0.78f), RoundedCornerShape(6.dp * scale))
                    .border(1.dp * scale, AnsuColors.StrokeGlass, RoundedCornerShape(6.dp * scale))
                    .padding(horizontal = 10.dp * scale, vertical = 5.dp * scale),
            )
        }

        // The burned-in progress bar only makes sense while the episode is still going.
        if (info == null || info is ResumeCardInfo.Remaining) {
            Box(modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth().height(3.dp * scale).background(AnsuColors.TextPrimary.copy(alpha = 0.2f)))
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth(progressFraction(entry.positionSeconds, entry.durationSeconds))
                    .height(3.dp * scale)
                    .background(AnsuColors.Accent),
            )
        }
    }
}

private class CardCoordinates { var value: LayoutCoordinates? = null }

/**
 * Wide frosted-look continue-watching card. A tap resumes; a press-and-hold (when [onLongPress] is given)
 * hands the thumbnail's on-screen rectangle to the caller, which floats the card into the action menu.
 * While [hidden] the card keeps its place in the row but is invisible, because its twin is in the air.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ContinueWatchingCard(
    entry: ContinueWatchingEntity,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    hidden: Boolean = false,
    onLongPress: ((Rect) -> Unit)? = null,
    info: ResumeCardInfo? = null,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    // A gentle squeeze while the finger is down tells the person the hold is being read.
    val pressScale by animateFloatAsState(
        targetValue = if (pressed && onLongPress != null) 0.96f else 1f,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 600f),
        label = "continueCardPress",
    )
    val coords = remember { CardCoordinates() }
    Column(
        modifier = modifier
            .width(220.dp)
            .graphicsLayer {
                scaleX = pressScale
                scaleY = pressScale
                alpha = if (hidden) 0f else 1f
            }
            .combinedClickable(
                interactionSource = interaction,
                indication = null,
                onClick = {
                    onClick()
                },
                onLongClick = onLongPress?.let { callback ->
                    {
                        coords.value?.takeIf { it.isAttached }?.let { callback(it.boundsInRoot()) }
                    }
                },
            ),
    ) {
        ContinueWatchingThumbnail(
            entry = entry,
            info = info,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(14.dp))
                .onGloballyPositioned { coords.value = it },
        )
        Text(
            text = entry.title,
            style = MaterialTheme.typography.bodyMedium,
            color = AnsuColors.TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp),
        )
        if (!entry.isMovie) {
            // A Next Up / countdown card names the episode it is about; the others the one being watched.
            val shownEpisode = when (info) {
                is ResumeCardInfo.NextUp -> info.episodeNumber
                is ResumeCardInfo.Countdown -> info.episodeNumber
                else -> entry.episodeNumber
            }
            Text(
                text = "Episode ${shownEpisode.formatEpisodeNumber()}",
                style = MaterialTheme.typography.labelSmall,
                color = AnsuColors.TextTertiary,
            )
        }
    }
}

@Composable
fun ContinueWatchingRow(
    entries: List<ContinueWatchingEntity>,
    onClick: (ContinueWatchingEntity, ResumeCardInfo?) -> Unit,
    modifier: Modifier = Modifier,
    /** The entry whose card is currently floating in the action menu; its slot stays but draws nothing. */
    hiddenId: Int? = null,
    onLongPress: (ContinueWatchingEntity, Rect, ResumeCardInfo?) -> Unit = { _, _, _ -> },
    /** What is next for entries whose episode is finished (from the home screen); the row adds the "time left" state itself. */
    nextInfo: Map<Int, ResumeCardInfo> = emptyMap(),
) {
    LazyRow(
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(entries, key = { it.anilistId }) { entry ->
            val info = resumeInfoFor(entry, nextInfo[entry.anilistId])
            ContinueWatchingCard(
                entry = entry,
                onClick = { onClick(entry, info) },
                // Neighbours glide together when a card is removed, instead of jumping.
                modifier = Modifier.animateItem(),
                hidden = entry.anilistId == hiddenId,
                onLongPress = { bounds -> onLongPress(entry, bounds, info) },
                info = info,
            )
        }
    }
}

/**
 * Swipeable hero carousel: the poster fills the screen top to bottom, bottom scrim, centered title/genres,
 * and a centered "View Details" (white) + "Like" (frosted glass) button pair, with
 * page dots below. Auto-rotates every 3 seconds. [onToggleFavourite] calls straight through to the real AniList
 * favourite mutation; since [SAnime] doesn't carry a persisted favourite flag at the
 * shelf level, the heart's fill state is a local, optimistic per-session toggle rather
 * than a synced one (the Details page's heart is the source of truth for that).
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HeroCarousel(
    items: List<SAnime>,
    onClick: (SAnime) -> Unit,
    onToggleFavourite: (SAnime) -> Unit = {},
    /** AniList ids the user has hearted; a slide's heart is filled when its title is in here. */
    favouriteIds: Set<Int> = emptySet(),
    modifier: Modifier = Modifier,
    /** Resolves the title-logo image URL for an AniList id; null (or no logo) shows the plain text title. */
    logoFor: suspend (Int) -> String? = { null },
    /** A better portrait picture for a slide (TMDB's poster); null keeps the show's own AniList cover. */
    posterFor: suspend (SAnime) -> String? = { null },
    /** Every notification received so far, newest first; the bell at the banner's top right expands to list them. */
    notifications: List<NotificationEntry>? = null,
    onOpenNotification: (NotificationEntry) -> Unit = {},
    onNotificationsRead: () -> Unit = {},
    onClearNotifications: () -> Unit = {},
) {
    if (items.isEmpty()) return
    val shown = items.take(8)
    // Endless loop: the pager has an enormous page count and page N shows slide N % size, so swiping past the last
    // slide runs straight on to the first (and back from the first to the last). It starts in the middle, on slide 0.
    val loops = shown.size > 1
    val startPage = remember { (Int.MAX_VALUE / 2).let { it - it % shown.size } }
    val pagerState = rememberPagerState(initialPage = if (loops) startPage else 0, pageCount = { if (loops) Int.MAX_VALUE else shown.size })
    val activeIndex = pagerState.currentPage % shown.size
    // AniList id -> logo URL. A key with a null value means "looked up, no logo", so it is not asked twice.
    val logos = remember(logoFor) { mutableStateMapOf<Int, String?>() }
    val posters = remember(posterFor) { mutableStateMapOf<Int, String?>() }
    
    // Auto-rotate: the timer restarts after every settled page (so a manual swipe gets a full pause)
    // and never fires while a finger is on the pager.
    // It also waits for the screen to be in front: a slide that started while a details page was opening over
    // the home screen competed with that animation for frames.
    val resumed = rememberIsResumed()
    LaunchedEffect(shown, pagerState.settledPage) {
        kotlinx.coroutines.delay(4000)
        if (!resumed.value) {
            androidx.compose.runtime.snapshotFlow { resumed.value }.first { it }
            kotlinx.coroutines.delay(1500)
        }
        if (!pagerState.isScrollInProgress && shown.size > 1) {
            val nextPage = pagerState.currentPage + 1
            pagerState.animateScrollToPage(nextPage, animationSpec = tween(durationMillis = 700, easing = FastOutSlowInEasing))
        }
    }

    // Art is looked up lazily: the slide on screen plus the one before and the one after it (the carousel
    // loops, so the slide before the first is the last). Asking for all eight at once cost up to 24 requests
    // the moment Home opened, most for slides nobody had reached yet; now each swipe asks for one new slide.
    // A lookup the effect restarts away from just continues inside the repository, so nothing is lost.
    LaunchedEffect(shown, logoFor, posterFor, activeIndex) {
        for (step in -1..1) {
            val anime = shown[Math.floorMod(activeIndex + step, shown.size)]
            val id = anime.anilistId ?: continue
            if (!posters.containsKey(id)) launch { posters[id] = posterFor(anime) }
            if (!logos.containsKey(id)) launch { logos[id] = logoFor(id) }
        }
    }

    // One fixed height for every slide: the old fillMaxSize inside a scrolling list let each poster's own
    // image size decide the banner height, so it jumped while swiping and while images loaded.
    val screenHeight = LocalConfiguration.current.screenHeightDp
    val heroHeight = (screenHeight * 0.68f).dp.coerceIn(460.dp, 620.dp)

    Column(modifier = modifier.fillMaxWidth()) {
        // Draws from the very top of the window, behind the status bar (no inset padding above it).
        Box(modifier = Modifier.fillMaxWidth().height(heroHeight)) {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
            ) { page ->
                val anime = shown[page % shown.size]
                // 0 when this page is centred, -1/+1 when it is fully off to one side.
                val offset = ((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction).coerceIn(-1f, 1f)
                val isLiked = anime.anilistId?.let { it in favouriteIds } == true
                val heroImage = anime.anilistId?.let { posters[it] } ?: anime.posterUrl ?: anime.bannerUrl
                val logoUrl = anime.anilistId?.let { logos[it] }
                Box(
                    modifier = Modifier.fillMaxSize().posterTransitionOrigin(
                        posterUrl = heroImage,
                        cornerRadius = 0.dp,
                        // What the details page shrinks back into on a back press: this very slide, with its
                        // gradient and title, so the banner closes the way it looked, not as a bare picture.
                        cover = { bounds -> HeroSlideCover(anime, heroImage, logoUrl, bounds) },
                    ),
                ) {
                    HeroSlide(
                        anime = anime,
                        heroImage = heroImage,
                        logoUrl = logoUrl,
                        offset = offset,
                        isLiked = isLiked,
                        onClick = { onClick(anime) },
                        onToggleFavourite = { onToggleFavourite(anime) },
                    )
                }
            }

            // Keeps the status-bar icons legible over bright artwork.
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .height(96.dp)
                    .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.4f), Color.Transparent))),
            )

            // The bell at the top right: grows into the list of every notification received so far.
            if (notifications != null) {
                NotificationInbox(
                    entries = notifications,
                    onOpenEntry = onOpenNotification,
                    onMarkAllRead = onNotificationsRead,
                    onClear = onClearNotifications,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .statusBarsPadding()
                        .padding(top = 8.dp, start = 16.dp, end = 16.dp),
                )
            }
        }

        if (shown.size > 1) {
            Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.Center) {
                shown.indices.forEach { index ->
                    val selected = index == activeIndex
                    val dotWidth by animateDpAsState(
                        targetValue = if (selected) 18.dp else 6.dp,
                        animationSpec = tween(durationMillis = 300),
                        label = "heroDot",
                    )
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 3.dp)
                            .height(6.dp)
                            .width(dotWidth)
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (selected) AnsuColors.Accent else AnsuColors.TextTertiary),
                    )
                }
            }
        }
    }
}

/**
 * One hero slide: artwork, the fade into the page colour and the title / genres / buttons block. It is
 * the single source of the banner's look, drawn both by the carousel and by [HeroSlideCover], so the
 * details page can close into a banner that is pixel-for-pixel the one on the home screen.
 *
 * [imageSize] pins the artwork request to a size (the banner's own); the cover passes it so the picture
 * comes out of the memory cache the carousel filled instead of being decoded again at another size.
 */
@Composable
private fun HeroSlide(
    anime: SAnime,
    heroImage: String?,
    logoUrl: String?,
    offset: Float,
    isLiked: Boolean,
    onClick: () -> Unit,
    onToggleFavourite: () -> Unit,
    imageSize: IntSize? = null,
) {
    val context = LocalContext.current
    val imageModel: Any? = remember(heroImage, imageSize) {
        if (imageSize == null || heroImage == null) heroImage
        else ImageRequest.Builder(context).data(heroImage).size(imageSize.width, imageSize.height).crossfade(false).build()
    }
    Box(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.fillMaxSize().clipToBounds()) {
            // AniList's own portrait cover (extraLarge); the banner is only a fallback.
            // Slightly oversized and shifted against the swipe, so the art trails the page (parallax).
            if (heroImage.isNullOrBlank()) {
                // No artwork yet: the gradient design instead of an empty box (same parallax as a picture).
                NoArtGradient(
                    seed = anime.anilistId?.toString() ?: anime.title,
                    modifier = Modifier.graphicsLayer {
                        scaleX = 1.16f
                        scaleY = 1.16f
                        translationX = offset * size.width * 0.07f
                    },
                )
            } else {
                AsyncImage(
                    model = imageModel,
                    contentDescription = anime.title,
                    contentScale = ContentScale.Crop,
                    colorFilter = HeroBrightness,
                    modifier = Modifier
                        .fillMaxSize()
                        .background(AnsuColors.BackgroundElevated)
                        .graphicsLayer {
                            scaleX = 1.16f
                            scaleY = 1.16f
                            translationX = offset * size.width * 0.07f
                        },
                )
            }
        }
        // Fade into the page colour: the banner melts into "Continue Watching" below.
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        0f to Color.Transparent,
                        0.45f to Color.Transparent,
                        0.72f to AnsuColors.Background.copy(alpha = 0.7f),
                        1f to AnsuColors.Background,
                    ),
                ),
        )
        // Title, genres and buttons belong to the page, so they slide with it.
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 24.dp)
                .padding(bottom = 12.dp)
                .graphicsLayer { alpha = 1f - abs(offset) * 0.6f },
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            TitleLogo(
                title = anime.title,
                logoUrl = logoUrl,
                alignment = Alignment.Center,
                textAlign = TextAlign.Center,
                fontSize = 27.sp,
                uppercase = false,
                maxLogoWidth = 320.dp,
                maxLogoHeight = 130.dp,
            )
            anime.genres.take(3).takeIf { it.isNotEmpty() }?.let { genres ->
                Text(
                    text = genres.joinToString(" • ") + anime.releaseYear?.let { " • $it" }.orEmpty(),
                    color = AnsuColors.TextSecondary,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 16.dp),
            ) {
                Button(
                    onClick = onClick,
                    colors = ButtonDefaults.buttonColors(containerColor = AnsuColors.Accent, contentColor = AnsuColors.OnAccent),
                    shape = RoundedCornerShape(24.dp),
                    contentPadding = PaddingValues(horizontal = 28.dp, vertical = 12.dp),
                ) {
                    Text("View Details", color = AnsuColors.OnAccent, fontWeight = FontWeight.Bold)
                }
                HeavyGlassCard(modifier = Modifier.size(48.dp), shape = CircleShape, tintAlpha = 0.5f) {
                    IconButton(onClick = { onToggleFavourite() }, modifier = Modifier.fillMaxSize()) {
                        Icon(
                            imageVector = if (isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = if (isLiked) "Unlike" else "Like",
                            tint = AnsuColors.TextPrimary,
                        )
                    }
                }
            }
        }
    }
}

/**
 * The banner as the details page's open/close animation draws it under the shrinking window: the same
 * slide as the carousel plus the status-bar scrim, at rest (centred, not liked), non-interactive.
 * [bounds] is the banner's size on screen, which also pins the artwork's cache key.
 */
@Composable
private fun HeroSlideCover(anime: SAnime, heroImage: String?, logoUrl: String?, bounds: Size) {
    Box(modifier = Modifier.fillMaxSize()) {
        HeroSlide(
            anime = anime,
            heroImage = heroImage,
            logoUrl = logoUrl,
            offset = 0f,
            isLiked = false,
            onClick = {},
            onToggleFavourite = {},
            imageSize = IntSize(bounds.width.roundToInt().coerceAtLeast(1), bounds.height.roundToInt().coerceAtLeast(1)),
        )
        // Same status-bar scrim the carousel draws over its top edge.
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .height(96.dp)
                .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.4f), Color.Transparent))),
        )
    }
}

/** Slight lift for the hero artwork: about +12% brightness, so dark posters are not swallowed by the page. */
private val HeroBrightness = ColorFilter.colorMatrix(
    ColorMatrix(
        floatArrayOf(
            1.12f, 0f, 0f, 0f, 6f,
            0f, 1.12f, 0f, 0f, 6f,
            0f, 0f, 1.12f, 0f, 6f,
            0f, 0f, 0f, 1f, 0f,
        ),
    ),
)

/** Result of preparing a title logo: still loading, unusable (not a real logo), or ready to draw. */
private sealed interface LogoState {
    data object Loading : LogoState
    data object Unusable : LogoState
    class Ready(val bitmap: ImageBitmap) : LogoState {
        val ratio: Float get() = bitmap.width.toFloat() / bitmap.height.toFloat()
    }
}

/**
 * Downloads [url], crops away its transparent margins (many logos ship with a lot of empty padding,
 * which made them render tiny) and rejects images that are not logos at all: an opaque picture such
 * as a square poster has no transparent background, so it is reported [LogoState.Unusable] and the
 * caller shows the text title instead.
 */
@Composable
private fun rememberLogoState(url: String?): LogoState {
    val context = LocalContext.current
    val state by produceState<LogoState>(
        if (url == null) LogoState.Unusable else logoStateCache[url] ?: LogoState.Loading,
        url,
    ) {
        if (url == null) {
            value = LogoState.Unusable
            return@produceState
        }
        // A logo that was already prepared (the home banner's, drawn again by the details page's close
        // animation) is reused, so the second copy shows the lettering at once instead of the plain title first.
        logoStateCache[url]?.let {
            value = it
            return@produceState
        }
        value = withContext(Dispatchers.Default) {
            val result = context.imageLoader.execute(
                ImageRequest.Builder(context).data(url).allowHardware(false).size(900).build(),
            )
            val source = (result as? SuccessResult)?.drawable?.let { (it as? BitmapDrawable)?.bitmap }
                ?: return@withContext LogoState.Unusable
            trimLogo(source)?.let { LogoState.Ready(it.asImageBitmap()) } ?: LogoState.Unusable
        }
        (value as? LogoState.Ready)?.let { logoStateCache[url] = it }
    }
    return state
}

/** The most recently prepared logos by URL (main thread only), so a logo drawn twice is prepared once. */
private val logoStateCache = object : LinkedHashMap<String, LogoState.Ready>(16, 0.75f, true) {
    override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, LogoState.Ready>?): Boolean = size > 24
}

/**
 * Crops [source] to its visible pixels; null when it is blank or a picture rather than a logo.
 *
 * Faint glow/shadow pixels (alpha up to 48) are ignored when measuring the crop box, so a soft halo
 * no longer keeps the logo's empty margin and makes it render small. A picture is rejected when the
 * cropped box is almost solid (a poster or screenshot, even one with a thin transparent border) or
 * when its four corners are all opaque (a rectangle, which lettering never is).
 */
private fun trimLogo(source: Bitmap): Bitmap? {
    val w = source.width
    val h = source.height
    if (w < 2 || h < 2) return null
    val pixels = IntArray(w * h)
    source.getPixels(pixels, 0, w, 0, 0, w, h)
    var minX = w; var minY = h; var maxX = -1; var maxY = -1
    for (y in 0 until h) {
        for (x in 0 until w) {
            if ((pixels[y * w + x] ushr 24) > 48) {
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
            }
        }
    }
    if (maxX < 0) return null
    val bw = maxX - minX + 1
    val bh = maxY - minY + 1
    if (bw < 8 || bh < 8) return null

    var solid = 0
    for (y in minY..maxY) {
        for (x in minX..maxX) {
            if ((pixels[y * w + x] ushr 24) > 240) solid++
        }
    }
    val fill = solid.toFloat() / (bw * bh)
    // Lettering leaves plenty of see-through gaps inside its box; a picture fills it.
    if (fill > 0.82f) return null

    fun opaqueAt(x: Int, y: Int): Boolean = (pixels[y.coerceIn(0, h - 1) * w + x.coerceIn(0, w - 1)] ushr 24) > 200
    val inset = (minOf(bw, bh) * 0.03f).toInt().coerceAtLeast(1)
    val cornersOpaque = opaqueAt(minX + inset, minY + inset) && opaqueAt(maxX - inset, minY + inset) &&
        opaqueAt(minX + inset, maxY - inset) && opaqueAt(maxX - inset, maxY - inset)
    if (cornersOpaque) return null

    // A near-square or tall box is a poster/emblem, not a title line; drawn at logo size it reads as
    // a tiny thumbnail where the title should be.
    val ratio = bw.toFloat() / bh
    if (ratio < 0.9f && fill > 0.6f) return null

    return Bitmap.createBitmap(source, minX, minY, bw, bh)
}

/**
 * The show's title in its own poster lettering ([logoUrl], a transparent logo image). The logo is
 * trimmed of empty margins and scaled to fill [maxLogoWidth] x [maxLogoHeight] as far as its shape
 * allows, so wide and tall logos both read at a good size. Falls back to the plain text [title]
 * whenever no logo is on screen: the show has none, the image is not a real (transparent) logo, it
 * failed to load, or it is still on its way. A logo that never arrives used to leave the hero with
 * no title at all, and an empty hero is worse than a title that swaps to the lettering a moment
 * later.
 */
@Composable
fun TitleLogo(
    title: String,
    logoUrl: String?,
    alignment: Alignment,
    textAlign: TextAlign,
    fontSize: TextUnit,
    uppercase: Boolean,
    maxLogoWidth: Dp,
    maxLogoHeight: Dp,
    modifier: Modifier = Modifier,
) {
    val logo = rememberLogoState(logoUrl)
    when {
        logo is LogoState.Ready -> {
            // Size by visual area instead of fitting a fixed box: a squarish logo is allowed to be
            // taller, a very wide one wider, so every title reads at a similar weight rather than
            // some filling the box and others shrinking to a sliver.
            val ratio = logo.ratio
            val targetArea = maxLogoWidth.value * maxLogoHeight.value * 0.75f
            var width = kotlin.math.sqrt(targetArea * ratio)
            var height = width / ratio
            if (width > maxLogoWidth.value) { width = maxLogoWidth.value; height = width / ratio }
            if (height > maxLogoHeight.value) { height = maxLogoHeight.value; width = height * ratio }
            Image(
                bitmap = logo.bitmap,
                contentDescription = title,
                contentScale = ContentScale.Fit,
                alignment = alignment,
                modifier = modifier.size(width = width.dp, height = height.dp),
            )
        }
        // Anything but a ready logo: show the title, so the hero is never blank.
        else -> Text(
            text = if (uppercase) title.uppercase() else title,
            color = AnsuColors.TextPrimary,
            fontSize = fontSize,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            textAlign = textAlign,
            modifier = modifier,
        )
    }
}

@Composable
fun GenreChip(text: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(AnsuColors.BackgroundElevated)
            .padding(horizontal = 12.dp, vertical = 6.dp),
    ) {
        Text(text, style = MaterialTheme.typography.labelSmall, color = AnsuColors.TextSecondary)
    }
}

@Composable
fun StatItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    value: String,
    label: String,
    modifier: Modifier = Modifier,
    tint: Color = AnsuColors.TextPrimary,
) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
        Text(value, style = MaterialTheme.typography.titleSmall, color = tint, modifier = Modifier.padding(top = 4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = AnsuColors.TextTertiary)
    }
}

/** A clickable person card used for both the Characters and Staff grids on the details page. */
@Composable
fun PersonCard(imageUrl: String?, name: String, role: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier = modifier.width(88.dp).clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(88.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(AnsuColors.BackgroundElevated),
        ) {
            if (imageUrl != null) {
                AsyncImage(model = imageUrl, contentDescription = name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
        }
        Text(
            name,
            style = MaterialTheme.typography.labelSmall,
            color = AnsuColors.TextPrimary,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 6.dp),
        )
        Text(
            role,
            style = MaterialTheme.typography.labelSmall,
            color = AnsuColors.TextTertiary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
        )
    }
}
